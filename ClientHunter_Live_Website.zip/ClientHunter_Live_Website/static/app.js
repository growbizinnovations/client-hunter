﻿let activeTab = 'leads';

function switchTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
  document.getElementById(`tab-${tabId}`).classList.remove('hidden');
  document.querySelectorAll('[id^="tab-btn-"]').forEach(el => {
    el.className = 'pb-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center gap-2';
  });
  document.getElementById(`tab-btn-${tabId}`).className = 'pb-3 border-b-2 border-brand-500 text-brand-400 flex items-center gap-2 font-semibold';
  activeTab = tabId;
  if (tabId === 'leads') loadLeads();
  if (tabId === 'campaigns') loadCampaigns();
  if (tabId === 'inbox') loadInbox();
  if (tabId === 'cities') loadCities();
}

async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();
    document.getElementById('stat-cities').textContent = `${data.stats.scanned_cities} / ${data.stats.total_cities}`;
    document.getElementById('stat-leads').textContent = data.stats.total_leads;
    document.getElementById('stat-outdated').textContent = data.stats.outdated_leads;
    document.getElementById('stat-emails').textContent = data.stats.emails_found;
    document.getElementById('stat-sent-today').textContent = `${data.stats.today_sent} / ${data.stats.today_limit}`;
    document.getElementById('stat-warmup-info').textContent = `Warmup Day ${data.stats.warmup_day} (Cap: ${data.stats.today_limit})`;
    document.getElementById('stat-replies').textContent = data.stats.replies_received;
    document.getElementById('warmup-summary-text').textContent = `Day ${data.stats.warmup_day} Active (Limit: ${data.stats.today_limit} emails/day)`;

    const modeBadge = document.getElementById('mode-badge');
    if (data.dry_run) {
      modeBadge.className = 'px-3 py-1 text-xs font-semibold rounded-full bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 flex items-center gap-1.5';
      modeBadge.innerHTML = '<span class="w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></span> DRY RUN (Simulated)';
      document.getElementById('input-dry-run').checked = true;
    } else {
      modeBadge.className = 'px-3 py-1 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5';
      modeBadge.innerHTML = '<span class="w-2 h-2 rounded-full bg-emerald-400"></span> LIVE SENDING';
      document.getElementById('input-dry-run').checked = false;
    }

    const daemonBtn = document.getElementById('toggle-daemon-btn');
    if (data.daemon_running) {
      daemonBtn.className = 'px-4 py-2 text-sm font-semibold rounded-lg bg-rose-600 hover:bg-rose-500 text-white flex items-center gap-2 shadow-md transition';
      daemonBtn.innerHTML = '<i data-lucide="pause" class="w-4 h-4"></i> <span>Pause 24/7 Agent</span>';
    } else {
      daemonBtn.className = 'px-4 py-2 text-sm font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-2 shadow-md transition';
      daemonBtn.innerHTML = '<i data-lucide="play" class="w-4 h-4"></i> <span>Start 24/7 Autonomous Worker</span>';
    }
    lucide.createIcons();
  } catch (err) { console.error('Error loading stats:', err); }
}

async function loadLeads() {
  try {
    const res = await fetch('/api/leads');
    const leads = await res.json();
    document.getElementById('leads-count-label').textContent = `Showing ${leads.length} businesses`;
    const tbody = document.getElementById('leads-table-body');
    if (leads.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-500">No leads discovered yet. Click "Scan Next City" to start!</td></tr>';
      return;
    }
    tbody.innerHTML = leads.map(l => {
      let scoreBadge = '';
      if (l.outdated_score !== null) {
        scoreBadge = l.outdated_score >= 35 
          ? `<span class="px-2 py-0.5 text-xs font-bold rounded badge-outdated">Outdated (${l.outdated_score}/100)</span>`
          : `<span class="px-2 py-0.5 text-xs font-bold rounded badge-modern">Modern (${l.outdated_score}/100)</span>`;
      } else {
        scoreBadge = `<span class="text-xs text-slate-500">Pending audit</span>`;
      }

      let issuesList = (l.issues && l.issues.length > 0)
        ? `<ul class="text-[11px] text-slate-400 space-y-0.5 list-disc pl-4">${l.issues.slice(0, 2).map(i => `<li>${i}</li>`).join('')}</ul>`
        : `<span class="text-xs text-slate-500">None detected</span>`;

      let emailStr = (l.emails && l.emails.length > 0)
        ? `<span class="text-xs font-mono text-emerald-400">${l.emails.join('<br>')}</span>`
        : `<span class="text-xs text-slate-500">No email found</span>`;

      return `
        <tr class="hover:bg-slate-800/40 transition">
          <td class="px-4 py-3 font-medium text-white">
            <div>${l.business_name}</div>
            <a href="${l.website_url}" target="_blank" class="text-xs text-brand-400 hover:underline flex items-center gap-1 mt-0.5">
              ${l.domain} <i data-lucide="external-link" class="w-3 h-3"></i>
            </a>
          </td>
          <td class="px-4 py-3">
            <div class="text-xs font-semibold text-slate-200">${l.city}, ${l.state}</div>
            <div class="text-[11px] text-slate-400">${l.niche}</div>
          </td>
          <td class="px-4 py-3">${scoreBadge}</td>
          <td class="px-4 py-3 max-w-xs">${issuesList}</td>
          <td class="px-4 py-3">${emailStr}</td>
          <td class="px-4 py-3">
            <span class="px-2 py-0.5 text-xs font-semibold rounded bg-slate-800 text-slate-300 border border-darkborder">${l.status}</span>
          </td>
        </tr>
      `;
    }).join('');
    lucide.createIcons();
  } catch (err) { console.error('Error loading leads:', err); }
}

async function loadCampaigns() {
  try {
    const res = await fetch('/api/campaigns');
    const campaigns = await res.json();
    const list = document.getElementById('campaigns-list');
    if (campaigns.length === 0) {
      list.innerHTML = '<div class="text-center py-8 text-slate-500">No emails queued yet. Discovered outdated websites will generate pitches here.</div>';
      return;
    }
    list.innerHTML = campaigns.map(c => `
      <div class="p-4 rounded-xl bg-slate-900 border border-darkborder">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
          <div class="font-semibold text-white text-sm flex items-center gap-2">
            <i data-lucide="mail" class="w-4 h-4 text-brand-400"></i> ${c.subject}
          </div>
          <span class="px-2 py-0.5 text-xs font-bold rounded ${c.status === 'SENT' ? 'badge-sent' : 'badge-queued'}">${c.status}</span>
        </div>
        <div class="text-xs text-slate-400 mb-3 flex flex-wrap gap-4">
          <span><strong>To:</strong> ${c.recipient_email} (${c.business_name})</span>
          <span><strong>From:</strong> ${c.sender_account}</span>
          <span><strong>Type:</strong> ${c.email_type}</span>
        </div>
        <div class="p-3 rounded-lg bg-darkcard text-xs text-slate-300 font-mono whitespace-pre-wrap border border-darkborder/60">${c.body_text}</div>
      </div>
    `).join('');
    lucide.createIcons();
  } catch (err) { console.error('Error loading campaigns:', err); }
}

async function loadInbox() {
  try {
    const res = await fetch('/api/inbox');
    const msgs = await res.json();
    const list = document.getElementById('inbox-list');
    document.getElementById('inbox-count').textContent = msgs.length;
    if (msgs.length === 0) {
      list.innerHTML = '<div class="text-center py-8 text-slate-500">No prospect replies recorded yet. The agent checks inboxes automatically every 10 minutes.</div>';
      return;
    }
    list.innerHTML = msgs.map(m => `
      <div class="p-4 rounded-xl bg-slate-900 border border-purple-500/30">
        <div class="flex items-center justify-between mb-2">
          <div class="font-bold text-white text-sm">${m.business_name} (${m.sender_email})</div>
          <span class="px-2 py-0.5 text-xs font-bold rounded badge-replied">${m.intent}</span>
        </div>
        <div class="text-xs font-semibold text-slate-300 mb-1">Subject: ${m.subject}</div>
        <blockquote class="p-3 rounded-lg bg-darkcard text-xs text-slate-200 border-l-2 border-purple-500 my-2 whitespace-pre-wrap">${m.body}</blockquote>
        ${m.auto_responded ? `
          <div class="mt-3 p-3 rounded-lg bg-slate-950 border border-darkborder">
            <div class="text-xs font-semibold text-emerald-400 mb-1">🤖 Automated Requirements Request Sent:</div>
            <div class="text-xs text-slate-300 whitespace-pre-wrap font-mono">${m.auto_response_text}</div>
          </div>
        ` : ''}
      </div>
    `).join('');
    lucide.createIcons();
  } catch (err) { console.error('Error loading inbox:', err); }
}

async function loadCities() {
  try {
    const res = await fetch('/api/cities');
    const cities = await res.json();
    const tbody = document.getElementById('cities-table-body');
    tbody.innerHTML = cities.map((c, idx) => `
      <tr class="hover:bg-slate-800/40">
        <td class="px-4 py-2.5 text-xs text-slate-500 font-mono">${idx + 1}</td>
        <td class="px-4 py-2.5 font-medium text-white">${c.city}, ${c.state}</td>
        <td class="px-4 py-2.5 text-xs font-mono text-slate-400">${c.lon}°</td>
        <td class="px-4 py-2.5 text-xs">${c.scan_count > 0 ? `<span class="text-emerald-400 font-bold">${c.scan_count} times</span>` : '<span class="text-slate-500">0 (Pending)</span>'}</td>
        <td class="px-4 py-2.5 text-xs text-slate-400">${c.last_scanned_at}</td>
      </tr>
    `).join('');
  } catch (err) { console.error('Error loading cities:', err); }
}

async function triggerScan() {
  await fetch('/api/trigger/scan', { method: 'POST' });
  alert('Started scanning next city in background! Leads will populate shortly.');
  setTimeout(() => { loadStats(); loadLeads(); }, 3000);
}

async function triggerSend() {
  await fetch('/api/trigger/send', { method: 'POST' });
  alert('Email dispatcher initiated! Dispatching queued batch.');
  setTimeout(() => { loadStats(); loadCampaigns(); }, 3000);
}

async function triggerInbox() {
  await fetch('/api/trigger/inbox', { method: 'POST' });
  alert('Checking Gmail inboxes for new replies...');
  setTimeout(() => { loadStats(); loadInbox(); }, 3000);
}

async function toggleDaemon() {
  const res = await fetch('/api/daemon/toggle', { method: 'POST' });
  const data = await res.json();
  alert(data.message);
  loadStats();
}

async function testCredentials() {
  const user = document.getElementById('input-gmail-user').value;
  const pass = document.getElementById('input-gmail-pass').value;
  const msgBox = document.getElementById('settings-status-msg');
  msgBox.className = 'text-xs p-3 rounded-lg mt-2 bg-slate-800 text-slate-300 block';
  msgBox.textContent = 'Testing connection to Gmail SMTP...';
  const res = await fetch('/api/test-credentials', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ gmail_user: user, gmail_pass: pass })
  });
  const data = await res.json();
  if (data.success) {
    msgBox.className = 'text-xs p-3 rounded-lg mt-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 block';
    msgBox.textContent = '✅ ' + data.message;
  } else {
    msgBox.className = 'text-xs p-3 rounded-lg mt-2 bg-rose-500/20 text-rose-300 border border-rose-500/30 block';
    msgBox.textContent = '❌ ' + data.message;
  }
}

async function saveSettings() {
  const user = document.getElementById('input-gmail-user').value;
  const pass = document.getElementById('input-gmail-pass').value;
  const sender = document.getElementById('input-sender-name').value;
  const gemini = document.getElementById('input-gemini-key').value;
  const dryRun = document.getElementById('input-dry-run').checked;
  const msgBox = document.getElementById('settings-status-msg');

  const res = await fetch('/api/save-settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      gmail_user: user,
      gmail_pass: pass,
      sender_name: sender,
      gemini_key: gemini,
      dry_run: dryRun
    })
  });
  const data = await res.json();
  msgBox.className = 'text-xs p-3 rounded-lg mt-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 block';
  msgBox.textContent = '✅ ' + data.message;
  loadStats();
}

loadStats();
loadLeads();
setInterval(loadStats, 10000);
